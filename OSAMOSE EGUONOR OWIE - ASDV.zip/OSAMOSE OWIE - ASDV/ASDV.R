#STATISTICAL ANALYSIS

summary(Transposed_Dataset_Osamose_Owie)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`,summary)
tab <- Transposed_Dataset_Osamose_Owie(Transposed_Dataset_Osamose_Owie$`Country`)
sort(tab, decreasing = TRUE)
df <- Transposed_Dataset_Osamose_Owie
head(df, n=10)
describe(df)

install.packages("dplyr")
library(dplyr)

install.packages('psych')
library(psych)


by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Algeria',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Burundi',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Egypt, Arab Rep.',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'France',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Gambia, The',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Germany',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Guinea-Bissau',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Italy',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Lesotho',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Morocco',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Netherlands',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Spain',describe)
by(Transposed_Dataset_Osamose_Owie,Transposed_Dataset_Osamose_Owie$`Country`== 'Tunisia',describe)


Burundi_stat = filter(Transposed_Dataset_Osamose_Owie, Country == 'Burundi')  
stat_data_burundi = Burundi_stat[, c('GDP')]
head(stat_data_burundi,20)
summary(stat_data_burundi)

Gambia_stat = filter(Transposed_Dataset_Osamose_Owie, Country == 'Gambia, The')  
stat_data_Gambia = Gambia_stat[, c('GDP')]
head(stat_data_Gambia,20)
summary(stat_data_Gambia)
   
France_stat = filter(Transposed_Dataset_Osamose_Owie, Country == 'France')  
stat_data_France = France_stat[, c('GDP')]
head(stat_data_France,20)
summary(stat_data_France)

Germany_stat = filter(Transposed_Dataset_Osamose_Owie, Country == 'Germany')  
stat_data_Germany = Germany_stat[, c('GDP')]
head(stat_data_Germany,20)
summary(stat_data_Germany)

is.null(Transposed_Dataset_Osamose_Owie)



#CORRELATION ANALYSIS
#Installing necessary packages
install.packages('corrplot')
library(corrplot)

#Exploratory data analysis
Transposed_Dataset_Osamose_Owie
colnames(Transposed_Dataset_Osamose_Owie)
is.null(Transposed_Dataset_Osamose_Owie)
str(Transposed_Dataset_Osamose_Owie)


#Selecting only numerical columns
df_cor <- Transposed_Dataset_Osamose_Owie[, c('GDP','Access_to_electricity','Access_to_electricity_urban','Antiretroviraltherapy_coverage','Children_living_with_HIV','Children_newly_infected','Current_health_expenditure','International_tourism','Labor_force_female','Labor_force','Exports_of_goods_and_services','Mobile_cellular_subscriptions','Urban_population','Individuals_using_the_Internet')]
head(df_cor,20)


#Plotting a correlation plot for all variables and countries
corrplot(cor(df_cor),
         method = "number",
         tl.cex = 0.5,
         type = "upper" # show only upper
)


#ALGERIA
Algeria_data = filter(Transposed_Dataset_Osamose_Owie, Country == 'Algeria')

corr_data_algeria = Algeria_data[, c('GDP','International_tourism','Labor_force_female','Exports_of_goods_and_services','Individuals_using_the_Internet')]
corrplot(cor(corr_data_algeria),
         method = "number",
         tl.cex = 0.7,
         type = "upper" # show only upper
)

#Scatter plot for Algeria
install.packages('ggplot2')
library(ggplot2)

ggplot(corr_data_algeria) +
  aes(x = GDP, y = International_tourism) +
  geom_point(colour = "#0c4c8a") +
  theme_minimal()

# Pearson correlation test
test <- cor.test(Algeria_data$GDP, Algeria_data$International_tourism)
test

#MOROCCO
Morocco_data = filter(Transposed_Dataset_Osamose_Owie, Country == 'Morocco')

corr_data_morocco = Morocco_data[, c('GDP','International_tourism','Labor_force_female','Exports_of_goods_and_services','Individuals_using_the_Internet')]
corrplot(cor(corr_data_morocco),
         method = "number",
         tl.cex = 0.7,
         type = "upper" # show only upper
)
#Scatter plot for Morocco
ggplot(corr_data_morocco) +
  aes(x = GDP, y = Individuals_using_the_Internet) +
  geom_point(colour = "#0c4c8a") +
  theme_minimal()

ggplot(corr_data_morocco) +
  aes(x = GDP, y = Labor_force_female) +
  geom_point(colour = "#0c4c8a") +
  theme_minimal()

# Pearson correlation test
test <- cor.test(Morocco_data$GDP, Morocco_data$Individuals_using_the_Internet)
test

test <- cor.test(Morocco_data$GDP, Morocco_data$Labor_force_female)
test

#ITALY
Italy_data = filter(Transposed_Dataset_Osamose_Owie, Country == 'Italy')

corr_data_italy = Italy_data[, c('GDP','International_tourism','Labor_force_female','Exports_of_goods_and_services','Individuals_using_the_Internet')]
corrplot(cor(corr_data_italy),
         method = "number",
         tl.cex = 0.7,
         type = "upper" # show only upper
)

#Scatter plot for Italy
ggplot(corr_data_italy) +
  aes(x = GDP, y = Exports_of_goods_and_services) +
  geom_point(colour = "#0c4c8a") +
  theme_minimal()

# Pearson correlation test
test <- cor.test(Italy_data$GDP, Italy_data$Exports_of_goods_and_services)
test

#SPAIN
Spain_data = filter(Transposed_Dataset_Osamose_Owie, Country == 'Spain')

corr_data_spain = Spain_data[, c('GDP','International_tourism','Labor_force_female','Exports_of_goods_and_services','Individuals_using_the_Internet')]
corrplot(cor(corr_data_spain),
         method = "number",
         tl.cex = 0.7,
         type = "upper" # show only upper
)

#Scatter plot for Spain
ggplot(corr_data_spain) +
  aes(x = GDP, y = Exports_of_goods_and_services) +
  geom_point(colour = "#0c4c8a") +
  theme_minimal()

# Pearson correlation test
test <- cor.test(Spain_data$GDP, Spain_data$Exports_of_goods_and_services)
test

install.packages("dplyr")
library(dplyr)


install.packages('psych')
library(psych)




