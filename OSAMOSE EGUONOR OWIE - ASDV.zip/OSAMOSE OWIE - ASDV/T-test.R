#One sample t-test
#Let's inspect our data frame

head(Transposed_Dataset_Osamose_Owie)

summary(Transposed_Dataset_Osamose_Owie)

dim(Transposed_Dataset_Osamose_Owie)

hist(Transposed_Dataset_Osamose_Owie$GDP)

#checking the mean and standard deviation

mean(Transposed_Dataset_Osamose_Owie$GDP)
sd(Transposed_Dataset_Osamose_Owie$GDP)

data_1 <- filter(Transposed_Dataset_Osamose_Owie, Country == 'Gambia, The') 
head(data_1)



#Checking for normality of the data
log_y <- log10(data_1$GDP)


#create histogram for original distribution
hist(data_1$GDP, col='steelblue', main='Original')

#create histogram for log-transformed distribution 
hist(log_y, col='coral2', main='Log Transformed')


#perform Shapiro-Wilk Test on original data
shapiro.test(data_1$GDP)

#perform Shapiro-Wilk Test on log-transformed data 
shapiro.test(log_y)

#Performing the t-test
t.test(data_1$GDP, mu=859440416435, alternative = "less")


#T test for Italy
data_2 <- filter(Transposed_Dataset_Osamose_Owie, Country == 'Italy') 
head(data_2)


#Checking for normality of the data
log_y2 <- log10(data_2$GDP)


#create histogram for original distribution
hist(data_2$GDP, col='steelblue', main='Original')

#create histogram for log-transformed distribution 
hist(log_y2, col='coral2', main='Log Transformed')


#perform Shapiro-Wilk Test on original data
shapiro.test(data_2$GDP)

#perform Shapiro-Wilk Test on log-transformed data 
shapiro.test(log_y2)

data_log <- as.data.frame(log_y2)
head(data_log)
x <- c(log_y2)

t.test(data_2$GDP , mu=859440416435, alternative = "less")








