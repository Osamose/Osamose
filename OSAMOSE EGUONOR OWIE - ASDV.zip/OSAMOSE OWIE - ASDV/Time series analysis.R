#TIME SERIES ANALYSIS

#Importing necessary packages
install.packages("TTR")
install.packages("forecast")


library("TTR")
library("forecast")


#Reading the data in a time series object
df <- (Transposed_Dataset_Osamose_Owie$GDP)
dftimeseries <- ts(df, frequency=12, start=c(2006,1))
dftimeseries

#Plotting the time series
plot.ts(dftimeseries, main = 'Time series for GDP',xlab="Time", ylab="GDP")
head(df,50)


logdftimeseries <- log(dftimeseries)
plot.ts(dftimeseries)



#Decomposing seasonal data
dftimeseriescomponents <- decompose(dftimeseries)
dftimeseriesseasonallyadjusted <- dftimeseries - dftimeseriescomponents$seasonal

plot(dftimeseriesseasonallyadjusted)

#Decomposition of additive time data
dftimeseriescomponents <- decompose(dftimeseries)

dftimeseriescomponents$seasonal 

plot(dftimeseriescomponents)



#Holt-Winters Exponential Smoothing (additive model with increasing or decreasing trend and seasonality)
logdftimeseries <- log(dftimeseries)
dftimeseriesforecasts <- HoltWinters(logdftimeseries)
dftimeseriesforecasts

plot(dftimeseriesforecasts)


dftimeseriesforecasts$SSE


#Plot for holt winters exponential filtering
plot(dftimeseriesforecasts)



#Plot for holt winters predictions
dftimeseriesforecasts2 <- forecast(dftimeseriesforecasts,h=48)
plot(dftimeseriesforecasts2)

#making a correlogram and carrying out the Ljung-Box test
acf(dftimeseriesforecasts2$residuals, lag.max=20 , na.action = na.pass)
Box.test(dftimeseriesforecasts2$residuals, lag=20, type="Ljung-Box")


#Time plot for the forecast errors
plot.ts(dftimeseriesforecasts2$residuals)


#Histogram for the forecast errors
dftimeseriesforecasts2$residuals <- dftimeseriesforecasts2$residuals [!is.na(dftimeseriesforecasts2$residuals)]
plotForecastErrors(skirtsseriesforecasts2$residuals)
hist(plotForecastErrors(skirtsseriesforecasts$residuals))
install.packages("dplyr")
library(dplyr)

plotForecastErrors <- function(forecasterrors)
{
  dftimeseriesforecasts2$residuals <- dftimeseriesforecasts2$residuals [!is.na(dftimeseriesforecasts2$residuals)]
  plotForecastErrors(skirtsseriesforecasts2$residuals)
  hist(plotForecastErrors(skirtsseriesforecasts$residuals))
}
hist()

