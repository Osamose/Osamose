
#REGRESSION ANALYSIS
#dropping any categorical variables
df_reg <- Transposed_Dataset_Osamose_Owie[, c('GDP','Access_to_electricity','Access_to_electricity_urban','Antiretroviraltherapy_coverage','Children_living_with_HIV','Children_newly_infected','Current_health_expenditure','International_tourism','Labor_force_female','Labor_force','Exports_of_goods_and_services','Mobile_cellular_subscriptions','Urban_population','Individuals_using_the_Internet')]
head(df_reg,20)
str(df_reg)

#Corrolation plot for all variables of the dataset
corrplot(cor(df_reg),
         method = "number",
         tl.cex = 0.5,
         type = "upper" # show only upper
)

#Using the Linear model function to perform regression
model_2 <-lm(GDP ~ Labor_force + Urban_population, df_reg) 
summary.lm(model_2)

?lm

model_3 <-lm(GDP ~ Labor_force + Urban_population + Mobile_cellular_subscriptions , df_reg) 
summary.lm(model_3)


model_4 <-lm(GDP ~ Labor_force + Urban_population + Mobile_cellular_subscriptions + Individuals_using_the_Internet , df_reg) 
summary.lm(model_4)

model_5 <-lm(GDP ~ Labor_force + Urban_population + Individuals_using_the_Internet , df_reg) 
summary.lm(model_5)

model_6 <-lm(GDP ~ Labor_force + Urban_population + Mobile_cellular_subscriptions , df_reg) 
summary.lm(model_6)

model_7 <-lm(GDP ~ Labor_force + Urban_population, df_reg) 
summary.lm(model_7)

model_8 <-lm(GDP ~ Urban_population + Mobile_cellular_subscriptions + Individuals_using_the_Internet , df_reg) 
summary.lm(model_8)

model_9 <-lm(GDP ~ Mobile_cellular_subscriptions + Individuals_using_the_Internet , df_reg) 
summary.lm(model_9)



#Checking for linearity among selected variables
data.frame(colnames(df_reg))

pairs(df_reg[,c(1,10,13,12,14)], lower.panel = NULL, pch = 19,cex = 0.2)



#PLOTS FOR REGRESSION ANALYSIS
#Residuals independence
plot(model_4, 1)

#Normality
plot(model_4, 2)

#Plotting a histogram to check normality
#installing necessary packages
install.packages('tidyverse')
library(tidyverse)

glimpse(Transposed_Dataset_Osamose_Owie)

ggplot(data = df_reg, aes(x = model_4$residuals)) +
  geom_histogram(fill = 'steelblue', color = 'black') +
  labs(title = 'Histogram of Residuals', x = 'Residuals', y = 'Frequency')

#Homoscedasticity
plot(model_4, 3)

#multicollinearity
vif(model_4)

install.packages('car')
library(car)


#Performing a RIDGE REGRESSION model due to multicollinearity
install.packages('glmnet')
library(glmnet)

#define response variable
df_multico <- Transposed_Dataset_Osamose_Owie[, c('GDP','Access_to_electricity','Access_to_electricity_urban','Antiretroviraltherapy_coverage','Children_living_with_HIV','Children_newly_infected','Current_health_expenditure','International_tourism','Labor_force_female','Labor_force','Exports_of_goods_and_services','Mobile_cellular_subscriptions','Urban_population','Individuals_using_the_Internet')]


#fit ridge regression model
#define matrix of predictor variables
x <- data.matrix(df_multico[, c('Labor_force', 'Urban_population', 'Mobile_cellular_subscriptions', 'Individuals_using_the_Internet')])
y <- df_multico$GDP
model <- glmnet(x, y, alpha = 0)

#view summary of model
summary(model)



#perform k-fold cross-validation to find optimal lambda value
cv_model <- cv.glmnet(x, y, alpha = 0)

#find optimal lambda value that minimizes test MSE
best_lambda <- cv_model$lambda.min
best_lambda



#produce plot of test MSE by lambda value
plot(cv_model)

#find coefficients of best model
best_model <- glmnet(x, y, alpha = 0, lambda = best_lambda)
coef(best_model)

#produce Ridge trace plot
plot(model, xvar = "lambda")

#use fitted best model to make predictions
y_predicted <- predict(model, s = best_lambda, newx = x)

#find SST and SSE
sst <- sum((y - mean(y))^2)
sse <- sum((y_predicted - y)^2)

#find R-Squared on this model
rsq <- 1 - sse/sst
rsq


