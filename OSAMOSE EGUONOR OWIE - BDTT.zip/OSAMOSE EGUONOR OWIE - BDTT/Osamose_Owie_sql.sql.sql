-- Databricks notebook source
--Implementing the task in SQL

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #listing the contents of the dbfs directory
-- MAGIC dbutils.fs.ls("dbfs:/FileStore/tables")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #Importing the datasets
-- MAGIC from pyspark.sql.types import *
-- MAGIC
-- MAGIC oneSchema = StructType([
-- MAGIC     StructField("Id", StringType()),
-- MAGIC     StructField("Sponsor",  StringType()),
-- MAGIC     StructField("Status",  StringType()),
-- MAGIC     StructField("Start",  StringType()),
-- MAGIC     StructField("Completion", StringType() ),
-- MAGIC     StructField("Type",  StringType()),
-- MAGIC     StructField("Submission",  StringType()),
-- MAGIC     StructField("Conditions", StringType() ),
-- MAGIC     StructField("Interventions",  StringType())
-- MAGIC ])
-- MAGIC
-- MAGIC
-- MAGIC trial_df = spark.read.options(delimiter="|", header=True).schema(oneSchema).csv("dbfs:/FileStore/tables/clinicaltrial_2021.csv")
-- MAGIC pharma_df = spark.read.options(delimiter=",", header=True, inferSchema=True).csv("dbfs:/FileStore/tables/pharma.csv")
-- MAGIC
-- MAGIC
-- MAGIC
-- MAGIC
-- MAGIC pharma_df.show(1, truncate=False)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC trial_df.show(5, truncate=False)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC trial_df.createOrReplaceTempView("Trials")

-- COMMAND ----------

SHOW TABLES

-- COMMAND ----------

--creating the database
CREATE DATABASE my_db

-- COMMAND ----------

--Creating the table Clinical_Database from trials
CREATE OR REPLACE TABLE my_db.trials AS SELECT * FROM trials

-- COMMAND ----------

SHOW TABLES in my_db

-- COMMAND ----------

SELECT * FROM my_db.trials LIMIT 5

-- COMMAND ----------

-- MAGIC %python
-- MAGIC pharma_df.createOrReplaceTempView("Pharma")

-- COMMAND ----------

--Creating Pharma Database
CREATE OR REPLACE TABLE my_db.pharma AS SELECT * FROM pharma

-- COMMAND ----------

SELECT * FROM my_db.pharma LIMIT 5

-- COMMAND ----------

--#Question 1: The number of studies in the dataset
SELECT DISTINCT COUNT(ID) FROM my_db.trials

-- COMMAND ----------

--#Question 2: The types of studies alongside their frequencies
SELECT Type, COUNT(Type) FROM  my_db.trials
GROUP BY Type
ORDER BY COUNT(Type) DESC


-- COMMAND ----------

--#Question 3: The Top 5 conditions with their frequencies
create table my_db.freqlist AS
SELECT
  explode(split(Conditions, ","))
FROM
  my_db.trials;
SELECT col, count(col)
FROM
  my_db.freqlist
group by
  col
order by
  count(col) desc
limit
  5;

-- COMMAND ----------

--#Question 4: The 10 most common sponsors that are not pharmaceutical companies, along with the number of clinical trials
SELECT Sponsor, COUNT(Sponsor) FROM my_db.trials 
WHERE Sponsor NOT IN ( SELECT DISTINCT Parent_Company FROM my_db.pharma)
GROUP BY Sponsor
ORDER BY COUNT(Sponsor) DESC limit 10;

-- COMMAND ----------

--#Question 5: A table showing the number of completed studies each month in a given year
SELECT LEFT(Completion,3) as month, COUNT(*) AS studies_count
FROM my_db.trials
WHERE Status = 'Completed' AND Completion LIKE "%2021"
GROUP BY LEFT(Completion,3)
ORDER BY month ASC

-- COMMAND ----------

--#EXTRA QUERIES

-- COMMAND ----------

--Further analysis on question 5
SELECT Sponsor, COUNT(Sponsor) AS Frequency
FROM(SELECT Sponsor, Parent_Company
FROM my_db.trials as dt LEFT JOIN my_db.pharma as P ON dt.Sponsor = P.Parent_Company)
WHERE Parent_Company IS NULL
AND Sponsor NOT LIKE '%Pharma%'
GROUP BY Sponsor
ORDER BY Frequency DESC
LIMIT 10;

-- COMMAND ----------

SELECT COUNT(Parent_Company) AS Count_Parent_Company, HQ_Country_of_Parent
FROM my_db.pharma
GROUP BY HQ_Country_of_Parent
ORDER BY Count_Parent_Company DESC;

-- COMMAND ----------

SELECT DISTINCT(Offense_Group)
FROM my_db.Pharma

-- COMMAND ----------

SELECT Company, Offense_Group, Penalty_Amount
FROM my_db.pharma
WHERE Offense_Group LIKE '%health%' AND Penalty_Amount LIKE '%000,000%' ;

-- COMMAND ----------

DESCRIBE my_db.trials

-- COMMAND ----------

DESCRIBE my_db.pharma
