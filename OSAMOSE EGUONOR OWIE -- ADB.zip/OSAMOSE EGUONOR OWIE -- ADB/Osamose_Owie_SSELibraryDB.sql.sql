-- Creating the database
CREATE DATABASE SSELibraryDB;

USE SSELibraryDB;
GO

CREATE TABLE Membership (
MembershipID int NOT NULL PRIMARY KEY IDENTITY(1,1),
MemberFirstName nvarchar(50) NOT NULL,
MemberMiddleName nvarchar(50) NULL,
MemberLastName nvarchar(50) NOT NULL,
MemberAddress1 nvarchar(50) NOT NULL,
MemberAddress2 nvarchar(50) NULL,
MemberCity nvarchar(50) NULL,
MemberPostcode nvarchar(10) NOT NULL
CONSTRAINT UC_Address UNIQUE (MemberAddress1, MemberPostcode),
MemberUsername nvarchar(50) UNIQUE NOT NULL CHECK (MemberUsername LIKE '%_@_%._%'),
MemberPassword nvarchar(10) UNIQUE NOT NULL,
MemberEmail nvarchar(100) UNIQUE NULL CHECK (MemberEmail LIKE '%_@_%._%'),
MemberTelephone nvarchar(20) NULL,
MemberGender nvarchar(15) NOT NULL,
MemberDOB date NOT NULL );

CREATE TABLE Payments (
RepaymentID int PRIMARY KEY NOT NULL IDENTITY(1,1),
loanID int FOREIGN KEY(LoanID) REFERENCES Loan(LoanID),
FineCharge money NOT NULL,
OverdueBooks int NOT NULL,
RepaidAmount money NOT NULL,
OutstandingBalance money NOT NULL,
RepaymentDate Date NOT NULL,
RepaymentAmount money NOT NULL,
RepaymentMethod nvarchar(4) NOT NULL CHECK(RepaymentMethod LIKE 'c%'),
);



CREATE TABLE Catalogue (
CatalogueID int NOT NULL PRIMARY KEY IDENTITY(1,1),
ItemTitle nvarchar (150) NOT NULL,
ItemType nvarchar (20) NOT NULL CHECK (ItemType LIKE 'Book' OR ItemType LIKE 'Journal' OR ItemType LIKE 'DVD' OR ItemType LIKE 'OtherMedia'),
Author nvarchar(250) NOT NULL,
YearofPublication Date NOT NULL,
DateAdded Date NOT NULL,
CurrentStatus nvarchar (20) NOT NULL CHECK (CurrentStatus LIKE 'OnLoan' OR CurrentStatus LIKE 'Overdue' OR CurrentStatus LIKE 'Available' OR CurrentStatus LIKE 'Lost/Removed'),
DateLost Date NULL,
ISBN nvarchar(50) NULL,
);

ALTER TABLE Catalogue ALTER COLUMN DateLost Date NULL;

ALTER TABLE Catalogue ALTER COLUMN ISBN nvarchar(50) NULL;

CREATE TABLE Loan (
LoanID int PRIMARY KEY NOT NULL IDENTITY(1,1),
CatalogueID int FOREIGN KEY(CatalogueID) REFERENCES Catalogue(CatalogueID),
CurrentLoan int NOT NULL,
PastLoan int NOT NULL,
MembershipID int FOREIGN KEY(MembershipID) REFERENCES Membership(MembershipID),
DateTaken Date NOT NULL,
DateDue Date NOT NULL,
DateReturned Date NOT NULL,
OverdueFine AS DATEDIFF(d, DateDue, GETDATE()) * 0.10 ,
RepaymentID int FOREIGN KEY REFERENCES Payments(RepaymentID),
OverdueStatus nvarchar(10) CHECK (OverdueStatus LIKE 'Yes' OR OverdueStatus LIKE 'No'),
);

CREATE TABLE ArchivedCustomers (
MembershipID int NOT NULL PRIMARY KEY IDENTITY(1,1),
MemberFirstName nvarchar(50) NOT NULL,
MemberMiddleName nvarchar(50) NULL,
MemberLastName nvarchar(50) NOT NULL,
MemberAddress1 nvarchar(50) NOT NULL,
MemberPostcode nvarchar(10) NOT NULL,
MemberEmail nvarchar(100) UNIQUE NULL CHECK (MemberEmail LIKE '%_@_%._%'),
MemberTelephone nvarchar(20) NULL,
MemberGender nvarchar(15) NOT NULL,
MemberDOB date NOT NULL,
);

DROP TRIGGER IF EXISTS members_delete_archive;
GO
CREATE TRIGGER members_delete_archive ON Membership
AFTER DELETE
AS BEGIN
INSERT INTO ArchivedCustomers
(MembershipID, MemberFirstName, MemberMiddleName, MemberLastName, MemberAddress1, MemberPostcode, MemberEmail,
MemberTelephone, MemberGender, MemberDOB)
SELECT
d.MembershipID, d.MemberFirstName, d.MemberMiddleName, d.MemberLastName, d.MemberAddress1, d.MemberPostcode, d.MemberEmail,d.MemberTelephone,
d.MemberGender, d.MemberDOB
FROM
deleted d
End;


DROP TRIGGER IF EXISTS terms_members_delete;
GO
CREATE TRIGGER terms_members_delete ON Payments
INSTEAD OF DELETE
AS BEGIN
DECLARE @id INT;
DECLARE @count INT;
SELECT @id = RepaymentID FROM DELETED;
SELECT @count = COUNT(*) FROM Payments WHERE OutstandingBalance like '1-9';
IF @count = 0
DELETE FROM Payments WHERE RepaymentID = @id;
ELSE
THROW 50000, 'Cannot delete this member because they have some fines yet to be paid', 1;
END;


DROP TRIGGER IF EXISTS terms_members_delete ;


INSERT INTO Membership 
VALUES ('Osamose', 'Eguonor', 'Owie', '36 Alban Street', NULL, 'Salford', 'M71NQ', 'osamose@SSElibrary.com', 'osas1*', 'osamosee@gmail.com', '07867265773', 'Female', '14-February-1997')

SELECT * FROM Membership;

INSERT INTO Membership 
VALUES ('Adedunmola', 'Charles', 'Adeiye', '20 Charles Street', '34 pete strees', 'Bury', 'B23SW', 'charles@SSElibrary.com', 'charles$2', 'charles@gmail.com', '07278326415', 'Male', '22-November-1997');

INSERT INTO Membership
VALUES ('Ejimofor', NULL, 'Chinweuba', '50 midway brook', NULL, 'Middlesborough', 'M35bs', 'Ejimofor@SSElibrary.com','ejil�2','Ejimofor@gmail.com', '07835241674','Male','2000-12-02');

INSERT INTO Membership
VALUES ('Prissy', NULL, 'Ediale', '20 french way', '35 brook way', 'London', 'L76MD', 'Prissy@SSElibrary.com','prissy','Prissy@gmail.com', '07538592057','Female','1992-07-02');

INSERT INTO Membership
VALUES ('Chukwudi', 'Pascal', 'Olarenwaju', '32 Freedomway', '20 ododo street', 'Birmingham', 'B98JK', 'Chukwudi@SSElibrary.com','Pascilo*2','Pascal@gmail.com', '07983526178','Male','1982-9-08');

INSERT INTO Membership
VALUES ('Caris', NULL, 'Brown', '98 Michigan way', NULL, 'Leicester', 'L98MK', 'chris@SSElibrary.com','chris8$', NULL, NULL ,'Female','1847-12-02');

DELETE FROM Membership WHERE MemberLastName like 'Brown';

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
SET IDENTITY_INSERT ArchivedCustomers ON
GO



SELECT * FROM ArchivedCustomers;

INSERT INTO Payments
VALUES (1, 4, 2, 2, 0, 4, '2023-02-04', 4, '2022-02-04', 'cash')

SELECT * FROM Payments;

INSERT INTO Payments
VALUES (3, 10, 5, 6, 4, 6, '2023-01-30', 6, '2023-03-14', 'card')

INSERT INTO Payments
VALUES (4, 10, 5, 3, 10, 0, '2022-01-30', 0, '2021-09-24', 'card')

DELETE FROM Payments WHERE RepaymentAmount = 0

INSERT INTO Payments
VALUES (4, 12, 6, 9, 12, 0, '2020-01-30', 0, '2023-10-22', 'card')

INSERT INTO Payments
VALUES (0, 12, 6, 9, 12, 0, '2020-01-30', 0, '2023-10-22', 'card')

INSERT INTO Payments
VALUES (2, 0, 0, 0, 0, 0, '2023-11-30', 0, '2023-1-2', 'card')

INSERT INTO Catalogue
VALUES ('A wild chase', 'Book', 'Valerie Queen', '1999-01-01', '2000-12-02', 'Available', NULL, 214658265433)

SELECT * FROM Catalogue;

INSERT INTO Catalogue
VALUES ('A midnight wonder', 'DVD', 'Chadwick boseman', '2000-11-12', '2015-03-01', 'OnLoan', NULL, NULL)

INSERT INTO Catalogue
VALUES ('SSS', 'Journal', 'Prof.Mo', '1906-04-12', '2002-11-09', 'Overdue', NULL, NULL)

INSERT INTO Catalogue
VALUES ('A secret affair', 'Book', 'Grey hound', '2000-11-12', '2015-03-01', 'Lost/Removed', '2023-01-01', 274623829863)

INSERT INTO Catalogue
VALUES ('Chandelier', 'OtherMedia', 'Sia aflek', '2022-01-23', '2019-08-11', 'Available', NULL, NULL)

INSERT INTO Loan
VALUES (4, 20, 10, 2, 'Book', '2023-01-01', '2023-01-14', '2023-01-31', 0.60, 2, 'Yes')

SELECT * FROM Loan;

INSERT INTO Loan
VALUES (5, 2, 14, 3, 'DVD', '2002-11-01', '2000-11-14', '2023-01-31', 2, 'Yes')

INSERT INTO Loan
VALUES (6, 8, 32, 4, 'Journal', '2022-11-01', '2023-01-02', '2023-01-31', 3, 'No')

INSERT INTO Loan
VALUES (8, 8, 3, 5, 'Book', '2022-11-01', '2023-01-02', '2023-01-31', 3, 'No')

INSERT INTO Loan
VALUES (10, 5, 12, 1, 'OtherMedia', '2022-11-01', '2023-01-02', '2023-01-31', 3, 'No')


SELECT * FROM Loan;
SELECT * FROM Payments;
SELECT * FROM Membership;
SELECT * FROM Catalogue;
SELECT * FROM ArchivedCustomers;


--QUESTION a
CREATE PROCEDURE SelectCate @name nvarchar(30)
AS
SELECT * FROM dbo.Catalogue WHERE ItemTitle LIKE @name + '%' ORDER BY YearofPublication DESC;

EXEC SelectCate @name = 'A'


--QUESTION b
CREATE FUNCTION Loandate(@Today AS DATE, @name AS nvarchar(50))
RETURNS TABLE AS
RETURN
( SELECT c.CurrentStatus, l.DateDue
FROM Catalogue AS c INNER JOIN Loan AS l
ON c.CatalogueID=l.CatalogueID
where DATEDIFF(DD, l.DateDue, GETDATE())<5 AND CurrentStatus LIKE 'On%' );


SELECT * FROM Loandate('2023-01-01','OnLoan') 

select * from Loan

SELECT GETDATE()

UPDATE dbo.Loan  
SET OverdueStatus = 'Yes'   
WHERE CurrentLoan = 8;

UPDATE dbo.Loan  
SET OverdueFine = 0 
WHERE MembershipID =1;



--RESERVE THIS TOO
SELECT GETDATE() AS CurrentDateTime,
CONVERT (DATE,GETDATE()) AS CurrentDate,
CONVERT (TIME,GETDATE()) AS CurrentTime,
DATEPART (YEAR,GETDATE()) AS CurrentYear,
DATEPART (MONTH,GETDATE()) AS CurrentMonth,
DATEPART (DAY,GETDATE()) AS CurrentDay;


--declaring the date function for this question
declare @Today date

Set @Today=getdate() --date will equal today    

Select *

FROM Loan
WHERE DateDue >= @Today



--QUESTION c
--Insert a new member into the database
CREATE PROCEDURE Allmembers
AS 
SELECT * FROM dbo.Membership;

EXEC Allmembers;

CREATE PROCEDURE Insert_Membersinfo
(
@MemberFirstname nvarchar(250),
@MemberMiddlename nvarchar(250)=null,
@MemberLastname nvarchar(250),
@MemberAddress1 nvarchar(50),
@MemberAddress2 nvarchar(50)=null,
@MemberCity nvarchar(50),
@MemberPostcode nvarchar(50),
@MemberUsername nvarchar(50),
@MemberPassword nvarchar(10),
@MemberEmail nvarchar(100)=null,
@MemberTelephone nvarchar(20)=null,
@MemberGender nvarchar(15),
@MemberDOB date
)
AS
BEGIN 
INSERT INTO Membership
	(
		MemberFirstname,
		MemberMiddlename,
		MemberLastname,
		MemberAddress1,
		MemberAddress2,
		MemberCity,
		MemberPostcode,
		MemberUsername,
		MemberPassword,
		MemberEmail,
		MemberTelephone,
		MemberGender,
		MemberDOB 
	)
    VALUES(
		@MemberFirstname,
		@MemberMiddlename,
		@MemberLastname,
		@MemberAddress1,
		@MemberAddress2,
		@MemberCity,
		@MemberPostcode,
		@MemberUsername,
		@MemberPassword,
		@MemberEmail,
		@MemberTelephone,
		@MemberGender,
		@MemberDOB
)
END;

EXEC Insert_Membersinfo
		@MemberFirstname = 'Quayum',
		@MemberMiddlename = NULL,
		@MemberLastname = 'Aladin',
		@MemberAddress1 = '5 Chadlane street',
		@MemberAddress2 = NULL,
		@MemberCity = 'Salford',
		@MemberPostcode = 'M503GH',
		@MemberUsername = 'Quayum@SSELibrary.com',
		@MemberPassword = 'Quay3&1',
		@MemberEmail = 'Quayum@gmail.com',
		@MemberTelephone = NULL,
		@MemberGender = 'Male',
		@MemberDOB = '1993-04-30';

SELECT * FROM Membership;


--QUESTION d
--Update the details for an existing member
CREATE PROCEDURE usp_UpdateMemberinfo
(@MembershipID int,
@MemberFirstname nvarchar(250),
@MemberMiddlename nvarchar(250)=null,
@MemberLastname nvarchar(250),
@MemberAddress1 nvarchar(50),
@MemberAddress2 nvarchar(50)=null,
@MemberCity nvarchar(50),
@MemberPostcode nvarchar(50),
@MemberUsername nvarchar(50),
@MemberPassword nvarchar(10),
@MemberEmail nvarchar(100)=null,
@MemberTelephone nvarchar(20)=null,
@MemberGender nvarchar(15),
@MemberDOB date )
AS 
BEGIN
INSERT INTO [Membership]
(MembershipID,
MemberFirstname ,
MemberMiddlename ,
MemberLastname ,
MemberAddress1 ,
MemberAddress2 ,
MemberCity ,
MemberPostcode ,
MemberUsername ,
MemberPassword ,
MemberEmail ,
MemberTelephone ,
MemberGender,
MemberDOB
	)
	SELECT MembershipID,
MemberFirstname,
MemberMiddlename ,
MemberLastname ,
MemberAddress1 ,
MemberAddress2 ,
MemberCity ,
MemberPostcode ,
MemberUsername ,
MemberPassword ,
MemberEmail ,
MemberTelephone ,
MemberGender,
MemberDOB FROM Membership WHERE MembershipID = @MembershipID

	--Update the data in employee table for the given EmployeeID
	UPDATE Membership
	SET MemberFirstname = @MemberFirstname,
		MemberMiddlename = @MemberMiddlename,
		MemberLastname = @MemberLastname,
		MemberAddress1 = @MemberAddress1,
		MemberAddress2 = @MemberAddress2,
		MemberCity = @MemberCity,
		MemberPostcode = @MemberPostcode,
		MemberUsername = @MemberUsername,
		MemberPassword = @MemberPassword,
		MemberEmail = @MemberEmail,
		MemberTelephone = @MemberTelephone,
		MemberGender = @MemberGender,
		MemberDOB = @MemberDOB
	WHERE MembershipID =  @MembershipID
END
	
EXEC usp_UpdateMemberinfo
		@MembershipID =  11,
		@MemberFirstname = 'Quayum',
		@MemberMiddlename = 'Baby',
		@MemberLastname = 'Odunuga',
		@MemberAddress1 = '5 Chadlane street',
		@MemberAddress2 = NULL,
		@MemberCity ='Salford',
		@MemberPostcode = 'M503GH',
		@MemberUsername = 'Quayum@SSELibrary.com',
		@MemberPassword = 'Quay3&1a',
		@MemberEmail = 'Quayum@gmail.com',
		@MemberTelephone = NULL,
		@MemberGender = 'Male',
		@MemberDOB = '1993-04-30'


SELECT * FROM Membership;



--QUESTION 3
--A VIEW FOR LOAN HISTORY
CREATE VIEW [Loan_Historys] AS
SELECT CurrentLoan, PastLoan, DateTaken, DateDue, OverdueFine
FROM Loan
WHERE OverdueStatus LIKE 'Y%';

SELECT * FROM [Loan_Historys]

SELECT * FROM Loan

--QUESTION 4
--Create a trigger so that the current status of an item automatically updates to Available when the book is returned.

CREATE TRIGGER update_status_new ON Catalogue
AFTER UPDATE
AS
BEGIN
SET NOCOUNT ON;
UPDATE Loan set DateTaken = GETDATE()
FROM Loan l
INNER JOIN inserted c on c.CatalogueID=l.CatalogueID
AND c.CurrentStatus = 'OnLoan'
UPDATE Loan set DateReturned = GETDATE()
FROM Loan l
INNER JOIN inserted c on c.CatalogueID=l.CatalogueID
AND c.CurrentStatus = 'Returned'
END
GO

CREATE TRIGGER new_status_books ON Catalogue
AFTER UPDATE
AS
BEGIN
SET NOCOUNT ON;
UPDATE Loan set DateReturned = GETDATE()
from Loan l
INNER JOIN Catalogue c on c.CatalogueID=l.CatalogueID
AND c.CurrentStatus = 'Available'
END
GO

UPDATE Catalogue
SET CurrentStatus='Available'
WHERE CatalogueID = 10;

SELECT * FROM Catalogue;
SELECT * FROM Loan;



--QUESTION 5
--To identify the total number of loans made on a specified date
CREATE VIEW [Daily_Loan] AS
SELECT COUNT(CurrentLoan) AS Current_Day_Loan_Count, DateTaken
FROM Loan
where DateTaken = '2022-11-01'
group by DateTaken
;

SELECT * FROM Daily_Loan;
SELECT * FROM Loan;

SELECT * FROM ArchivedCustomers;


--EXTRA QUERIES
SELECT c.Itemtype
     , m.MembershipID
  FROM Loan as l
  JOIN Membership as m
    ON m.MembershipID = l.MembershipID
  JOIN Catalogue as c
    ON c.CatalogueID = l.CatalogueID
 GROUP 
    BY m.MembershipID
     , c.ItemType
HAVING COUNT(*) >= 2;

SELECT * FROM Catalogue;
SELECT * FROM Membership;
SELECT * FROM Loan;
SELECT * FROM Payments;

ALTER TABLE Loan
DROP COLUMN Itemtype;

UPDATE Loan 
SET DateDue = '2003-02-01' where MembershipID = 3;

UPDATE Loan 
SET DateReturned = '2004-02-01' where MembershipID = 3;



ALTER TABLE Payments
ADD CONSTRAINT l_fk
FOREIGN KEY (LoanID) REFERENCES Loan(LoanID);

UPDATE Payments
SET RepaidAmount = 8.90
WHERE LoanID = 4

UPDATE Payments
SET FineCharge = 8.90
WHERE LoanID = 4


--RANDOM Query
select m.MemberFirstName + ' ' + isnull (m.MemberMiddleName,'') +' '+ m.MemberLastName as [Full Name], c.ItemType,c.DateAdded,
m.MemberAddress1 +''+m.MemberCity +''+m.MemberPostcode AS [Full Address] from dbo.Catalogue c 
inner join Loan l  on c.CatalogueID=l.CatalogueID inner join Membership m on l.MembershipID =m.MembershipID
where c.CatalogueID in (select l.CatalogueID
from Loan l
where l.OverdueFine>= 100
and c.DateAdded > '2000-12-11');

BEGIN TRY
Insert Into Catalogue(CatalogueID, ItemTitle, ItemType, Author, YearofPublication, DateAdded, CurrentStatus, DateLost, ISBN) Values (9, 'Maranatha', 'Book', 'Dunsin Oyekan', '2023-03-03', '2023-04-04', 'Available', NULL, 275683654628)
END TRY
BEGIN CATCH
	SELECT ERROR_MESSAGE() AS [Error Message]
		,ERROR_LINE() AS ErrorLine
		,ERROR_NUMBER() AS [Error Number]
		,ERROR_SEVERITY() AS [Error Severity]
		,ERROR_STATE() AS [Error State]
END CATCH


CREATE PROCEDURE [Creating Role] AS
-- Creates a manager role
CREATE ROLE Manager
-- CREATE Clerk role
CREATE ROLE Clerk
-- Create a role for an Analyst
CREATE ROLE Analyst
GO
CREATE PROCEDURE [Granting Role] AS
-- Grants creating tables and views to the manager
GRANT CREATE TABLE, CREATE VIEW
TO Manager
-- Grants inserting, updating and deleting to the clerk
GRANT INSERT, UPDATE, DELETE TO Clerk
-- Grant Select role to Analyst
GRANT SELECT TO Analyst
GO
CREATE PROCEDURE [Login] AS
CREATE LOGIN Manager WITH PASSWORD = 'MemberInfo�'
GO
CREATE PROCEDURE[User] AS
CREATE USER Dami for login Manager
GO
CREATE PROCEDURE[Granting Permission]
AS
GRANT SELECT ON Membership TO Dami
GRANT SELECT ON Catalogue TO Dami
GRANT SELECT ON Loan TO Dami
GRANT SELECT ON Payments TO Dami
GO



BACKUP DATABASE SSELibraryDB
TO DISK = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\Backup\SSELibraryDB.BAK'
GO


BACKUP DATABASE SSELibraryDB
TO DISK = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\Backup\SSELibraryDB.BAK'
WITH PASSWORD = 'F3BRU$R&'
GO


